#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cjson/cJSON.h"

// Les infos de chaque heros
int  id[20];
char nom[20][64];
int  intelligence[20];
int  force[20];
int  vitesse[20];
int  durabilite[20];
int  pouvoir[20];
int  combat[20];
char genre[20][32];
char race[20][64];
char taille[20][16];
char poids[20][16];
char yeux[20][32];
char cheveux[20][32];
int  nb_heros = 0;

// ============================================================
//                     CHARGEMENT DU JSON
// ============================================================

void charger_heroes() {
    FILE *f = fopen("SuperHeros.json", "rb");
    if (!f) {
        printf("Erreur : fichier SuperHeros.json introuvable !\n");
        system("pause");
        exit(1);
    }

    fseek(f, 0, SEEK_END);
    long taille_fichier = ftell(f);
    rewind(f);
    char *contenu = malloc(taille_fichier + 1);
    fread(contenu, 1, taille_fichier, f);
    contenu[taille_fichier] = '\0';
    fclose(f);

    cJSON *tableau = cJSON_Parse(contenu);
    free(contenu);

    if (!tableau) {
        printf("Erreur : JSON invalide !\n");
        system("pause");
        exit(1);
    }

    cJSON *hero;
    cJSON_ArrayForEach(hero, tableau) {
        cJSON *tmp;

        tmp = cJSON_GetObjectItemCaseSensitive(hero, "id");
        id[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;

        tmp = cJSON_GetObjectItemCaseSensitive(hero, "name");
        strncpy(nom[nb_heros], cJSON_IsString(tmp) ? tmp->valuestring : "inconnu", 63);

        cJSON *ps = cJSON_GetObjectItemCaseSensitive(hero, "powerstats");
        if (ps) {
            tmp = cJSON_GetObjectItemCaseSensitive(ps, "intelligence");
            intelligence[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;

            tmp = cJSON_GetObjectItemCaseSensitive(ps, "strength");
            force[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;

            tmp = cJSON_GetObjectItemCaseSensitive(ps, "speed");
            vitesse[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;

            tmp = cJSON_GetObjectItemCaseSensitive(ps, "durability");
            durabilite[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;

            tmp = cJSON_GetObjectItemCaseSensitive(ps, "power");
            pouvoir[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;

            tmp = cJSON_GetObjectItemCaseSensitive(ps, "combat");
            combat[nb_heros] = cJSON_IsNumber(tmp) ? tmp->valueint : -1;
        } else {
            intelligence[nb_heros] = -1;
            force[nb_heros]        = -1;
            vitesse[nb_heros]      = -1;
            durabilite[nb_heros]   = -1;
            pouvoir[nb_heros]      = -1;
            combat[nb_heros]       = -1;
        }

        cJSON *ap = cJSON_GetObjectItemCaseSensitive(hero, "appearance");
        if (ap) {
            tmp = cJSON_GetObjectItemCaseSensitive(ap, "gender");
            strncpy(genre[nb_heros],   cJSON_IsString(tmp) ? tmp->valuestring : "inconnu", 31);

            tmp = cJSON_GetObjectItemCaseSensitive(ap, "race");
            strncpy(race[nb_heros],    cJSON_IsString(tmp) ? tmp->valuestring : "inconnu", 63);

            tmp = cJSON_GetObjectItemCaseSensitive(ap, "eyeColor");
            strncpy(yeux[nb_heros],    cJSON_IsString(tmp) ? tmp->valuestring : "inconnu", 31);

            tmp = cJSON_GetObjectItemCaseSensitive(ap, "hairColor");
            strncpy(cheveux[nb_heros], cJSON_IsString(tmp) ? tmp->valuestring : "inconnu", 31);

            cJSON *h  = cJSON_GetObjectItemCaseSensitive(ap, "height");
            cJSON *h1 = cJSON_IsArray(h) ? cJSON_GetArrayItem(h, 1) : NULL;
            strncpy(taille[nb_heros], cJSON_IsString(h1) ? h1->valuestring : "inconnu", 15);

            cJSON *w  = cJSON_GetObjectItemCaseSensitive(ap, "weight");
            cJSON *w1 = cJSON_IsArray(w) ? cJSON_GetArrayItem(w, 1) : NULL;
            strncpy(poids[nb_heros], cJSON_IsString(w1) ? w1->valuestring : "inconnu", 15);
        } else {
            strncpy(genre[nb_heros],   "inconnu", 31);
            strncpy(race[nb_heros],    "inconnu", 63);
            strncpy(taille[nb_heros],  "inconnu", 15);
            strncpy(poids[nb_heros],   "inconnu", 15);
            strncpy(yeux[nb_heros],    "inconnu", 31);
            strncpy(cheveux[nb_heros], "inconnu", 31);
        }

        nb_heros++;
    }

    cJSON_Delete(tableau);
    printf("%d heros charges avec succes !\n", nb_heros);
}

// ============================================================
//                     FONCTIONNALITES
// ============================================================

void afficher_liste() {
    printf("\n");
    for (int i = 0; i < nb_heros; i++)
        printf("  ID : %-3d | Nom : %s\n", id[i], nom[i]);
    printf("\n");
}

void afficher_hero(int i) {
    printf("\n============================\n");
    printf("ID           : %d\n", id[i]);
    printf("Nom          : %s\n", nom[i]);
    printf("--- Powerstats ---\n");
    printf("  Intelligence : "); intelligence[i] == -1 ? printf("inconnue\n") : printf("%d\n", intelligence[i]);
    printf("  Force        : "); force[i]        == -1 ? printf("inconnue\n") : printf("%d\n", force[i]);
    printf("  Vitesse      : "); vitesse[i]      == -1 ? printf("inconnue\n") : printf("%d\n", vitesse[i]);
    printf("  Durabilite   : "); durabilite[i]   == -1 ? printf("inconnue\n") : printf("%d\n", durabilite[i]);
    printf("  Pouvoir      : "); pouvoir[i]      == -1 ? printf("inconnue\n") : printf("%d\n", pouvoir[i]);
    printf("  Combat       : "); combat[i]       == -1 ? printf("inconnue\n") : printf("%d\n", combat[i]);
    printf("--- Apparence ---\n");
    printf("  Genre        : %s\n", genre[i]);
    printf("  Race         : %s\n", race[i]);
    printf("  Taille       : %s\n", taille[i]);
    printf("  Poids        : %s\n", poids[i]);
    printf("  Yeux         : %s\n", yeux[i]);
    printf("  Cheveux      : %s\n", cheveux[i]);
    printf("============================\n\n");
}

void rechercher_par_id() {
    int recherche;
    printf("Entrez l'ID : ");
    scanf("%d", &recherche);

    for (int i = 0; i < nb_heros; i++) {
        if (id[i] == recherche) {
            afficher_hero(i);
            return;
        }
    }
    printf("Aucun heros avec l'ID %d\n\n", recherche);
}

void rechercher_par_nom() {
    char recherche[64];
    printf("Entrez le nom : ");
    scanf(" %63[^\n]", recherche);

    // Met en minuscules sans tolower
    for (int i = 0; recherche[i]; i++)
        if (recherche[i] >= 'A' && recherche[i] <= 'Z')
            recherche[i] = recherche[i] + 32;

    int trouve = 0;
    for (int i = 0; i < nb_heros; i++) {
        char nom_lower[64];
        for (int j = 0; nom[i][j]; j++) {
            if (nom[i][j] >= 'A' && nom[i][j] <= 'Z')
                nom_lower[j] = nom[i][j] + 32;
            else
                nom_lower[j] = nom[i][j];
        }
        nom_lower[strlen(nom[i])] = '\0';

        if (strstr(nom_lower, recherche)) {
            afficher_hero(i);
            trouve = 1;
        }
    }

    if (!trouve)
        printf("Aucun heros trouve avec le nom \"%s\"\n\n", recherche);
}

void filtrer_par_stat() {
    int choix_stat, operateur, seuil;

    printf("\nQuelle stat ?\n");
    printf("  1. Intelligence\n");
    printf("  2. Force\n");
    printf("  3. Vitesse\n");
    printf("  4. Durabilite\n");
    printf("  5. Pouvoir\n");
    printf("  6. Combat\n");
    printf("Votre choix : ");
    scanf("%d", &choix_stat);

    printf("Operateur (1 = superieur ou egal, 2 = inferieur ou egal) : ");
    scanf("%d", &operateur);

    printf("Valeur seuil (0-100) : ");
    scanf("%d", &seuil);

    int trouve = 0;
    printf("\n--- Resultats ---\n");
    for (int i = 0; i < nb_heros; i++) {
        int valeur;
        if      (choix_stat == 1) valeur = intelligence[i];
        else if (choix_stat == 2) valeur = force[i];
        else if (choix_stat == 3) valeur = vitesse[i];
        else if (choix_stat == 4) valeur = durabilite[i];
        else if (choix_stat == 5) valeur = pouvoir[i];
        else if (choix_stat == 6) valeur = combat[i];
        else { printf("Choix invalide.\n"); return; }

        if (valeur == -1) continue;

        int match = (operateur == 1) ? (valeur >= seuil) : (valeur <= seuil);
        if (match) {
            printf("  %-20s : %d\n", nom[i], valeur);
            trouve = 1;
        }
    }

    if (!trouve)
        printf("  Aucun heros ne correspond.\n");
    printf("\n");
}

void comparer_heroes() {
    afficher_liste();

    int id1, id2, i1 = -1, i2 = -1;
    printf("ID du 1er heros : ");
    scanf("%d", &id1);
    printf("ID du 2eme heros : ");
    scanf("%d", &id2);

    for (int i = 0; i < nb_heros; i++) {
        if (id[i] == id1) i1 = i;
        if (id[i] == id2) i2 = i;
    }

    if (i1 == -1) { printf("ID %d introuvable.\n\n", id1); return; }
    if (i2 == -1) { printf("ID %d introuvable.\n\n", id2); return; }

    int stats1[] = {intelligence[i1], force[i1], vitesse[i1], durabilite[i1], pouvoir[i1], combat[i1]};
    int stats2[] = {intelligence[i2], force[i2], vitesse[i2], durabilite[i2], pouvoir[i2], combat[i2]};
    char *labels[] = {"Intelligence", "Force", "Vitesse", "Durabilite", "Pouvoir", "Combat"};

    printf("\n  %-16s | %-15s | %-15s\n", "", nom[i1], nom[i2]);
    printf("  ------------------------------------------------\n");
    printf("  --- POWERSTATS ---\n");

    int score1 = 0, score2 = 0;
    for (int i = 0; i < 6; i++) {
        char s1[16], s2[16];
        if (stats1[i] == -1) snprintf(s1, 16, "inconnue");
        else                  snprintf(s1, 16, "%d", stats1[i]);
        if (stats2[i] == -1) snprintf(s2, 16, "inconnue");
        else                  snprintf(s2, 16, "%d", stats2[i]);

        char *resultat = "";
        if (stats1[i] != -1 && stats2[i] != -1) {
            if      (stats1[i] > stats2[i]) { resultat = "<-- gagne"; score1++; }
            else if (stats2[i] > stats1[i]) { resultat = "    gagne -->"; score2++; }
            else                             { resultat = "    egalite"; }
        }

        printf("  %-16s | %-15s | %-15s  %s\n", labels[i], s1, s2, resultat);
    }

    printf("  ------------------------------------------------\n");
    printf("  VERDICT : ");
    if      (score1 > score2) printf("%s gagne (%d stats contre %d) !\n\n", nom[i1], score1, score2);
    else if (score2 > score1) printf("%s gagne (%d stats contre %d) !\n\n", nom[i2], score2, score1);
    else                      printf("Egalite parfaite !\n\n");
}

// ============================================================
//                          MENUS
// ============================================================

void menu_recherche() {
    int choix = -1;
    while (choix != 0) {
        printf("\n=============================\n");
        printf("     RECHERCHE / FILTRE      \n");
        printf("=============================\n");
        printf("  1. Rechercher par nom\n");
        printf("  2. Filtrer par statistique\n");
        printf("  0. Retour\n");
        printf("=============================\n");
        printf("Votre choix : ");
        scanf("%d", &choix);

        if      (choix == 1) rechercher_par_nom();
        else if (choix == 2) filtrer_par_stat();
        else if (choix == 0) printf("Retour...\n");
        else                 printf("Choix invalide.\n");
    }
}

void afficher_menu() {
    printf("\n=============================\n");
    printf("       SUPERHEROS MENU       \n");
    printf("=============================\n");
    printf("  1. Lister tous les heros\n");
    printf("  2. Rechercher par ID\n");
    printf("  3. Recherche / Filtre\n");
    printf("  4. Comparer deux heros\n");
    printf("  0. Quitter\n");
    printf("=============================\n");
    printf("Votre choix : ");
}

// ============================================================
//                          MAIN
// ============================================================

int main(void) {
    charger_heroes();

    int choix = -1;
    while (choix != 0) {
        afficher_menu();
        scanf("%d", &choix);

        if      (choix == 1) afficher_liste();
        else if (choix == 2) rechercher_par_id();
        else if (choix == 3) menu_recherche();
        else if (choix == 4) comparer_heroes();
        else if (choix == 0) printf("Au revoir !\n");
        else                 printf("Choix invalide.\n");
    }

    return 0;
}